﻿namespace Hospital_Application
{
    partial class Login
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.Login_button = new System.Windows.Forms.Button();
            this.Password_txtbox = new System.Windows.Forms.TextBox();
            this.Username_txtbox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Login_button
            // 
            this.Login_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.Login_button.Location = new System.Drawing.Point(72, 273);
            this.Login_button.Name = "Login_button";
            this.Login_button.Size = new System.Drawing.Size(373, 53);
            this.Login_button.TabIndex = 5;
            this.Login_button.Text = "Login";
            this.Login_button.UseVisualStyleBackColor = true;
            this.Login_button.Click += new System.EventHandler(this.Login_button_Click);
            // 
            // Password_txtbox
            // 
            this.Password_txtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F);
            this.Password_txtbox.Location = new System.Drawing.Point(72, 161);
            this.Password_txtbox.Multiline = true;
            this.Password_txtbox.Name = "Password_txtbox";
            this.Password_txtbox.PasswordChar = '*';
            this.Password_txtbox.Size = new System.Drawing.Size(373, 55);
            this.Password_txtbox.TabIndex = 4;
            this.Password_txtbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Username_txtbox
            // 
            this.Username_txtbox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Username_txtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Username_txtbox.Location = new System.Drawing.Point(72, 61);
            this.Username_txtbox.Multiline = true;
            this.Username_txtbox.Name = "Username_txtbox";
            this.Username_txtbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Username_txtbox.Size = new System.Drawing.Size(373, 54);
            this.Username_txtbox.TabIndex = 3;
            this.Username_txtbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Username_txtbox.TextChanged += new System.EventHandler(this.Username_txtbox_TextChanged);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(509, 411);
            this.Controls.Add(this.Login_button);
            this.Controls.Add(this.Password_txtbox);
            this.Controls.Add(this.Username_txtbox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Login";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Login_button;
        private System.Windows.Forms.TextBox Password_txtbox;
        private System.Windows.Forms.TextBox Username_txtbox;
    }
}

