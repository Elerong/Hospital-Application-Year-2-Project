﻿namespace Hospital_Application
{
    partial class Central_Station
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Patients_List = new System.Windows.Forms.ListBox();
            this.Patient_panel = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Current_patient_notes = new System.Windows.Forms.Label();
            this.Current_patietn_view = new System.Windows.Forms.Button();
            this.Room_name = new System.Windows.Forms.Label();
            this.Break_txt = new System.Windows.Forms.Label();
            this.Current_patient_dob = new System.Windows.Forms.Label();
            this.patient_condition_txt = new System.Windows.Forms.Label();
            this.dob_txt = new System.Windows.Forms.Label();
            this.Current_patient_id = new System.Windows.Forms.Label();
            this.Patient_id_txt = new System.Windows.Forms.Label();
            this.Patient_name = new System.Windows.Forms.Label();
            this.Current_patient_room = new System.Windows.Forms.Label();
            this.Current_patient_pulse_colour = new System.Windows.Forms.Panel();
            this.Current_patient_condition = new System.Windows.Forms.Label();
            this.Current_patient_breathing_colour = new System.Windows.Forms.Panel();
            this.Current_patient_breathing = new System.Windows.Forms.Label();
            this.Current_patient_blood_colour = new System.Windows.Forms.Panel();
            this.Current_patient_blood = new System.Windows.Forms.Label();
            this.Current_patient_temp_colour = new System.Windows.Forms.Panel();
            this.Current_patient_temp = new System.Windows.Forms.Label();
            this.Welcome_message = new System.Windows.Forms.Label();
            this.Welcome_employee = new System.Windows.Forms.Label();
            this.Exit_btn = new System.Windows.Forms.Button();
            this.Add_patient_btn = new System.Windows.Forms.Button();
            this.Managment_btn = new System.Windows.Forms.Button();
            this.Patient_panel.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.Current_patient_pulse_colour.SuspendLayout();
            this.Current_patient_breathing_colour.SuspendLayout();
            this.Current_patient_blood_colour.SuspendLayout();
            this.Current_patient_temp_colour.SuspendLayout();
            this.SuspendLayout();
            // 
            // Patients_List
            // 
            this.Patients_List.FormattingEnabled = true;
            this.Patients_List.Location = new System.Drawing.Point(26, 23);
            this.Patients_List.Name = "Patients_List";
            this.Patients_List.Size = new System.Drawing.Size(239, 394);
            this.Patients_List.TabIndex = 4;
            this.Patients_List.SelectedIndexChanged += new System.EventHandler(this.Patients_List_SelectedIndexChanged);
            // 
            // Patient_panel
            // 
            this.Patient_panel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Patient_panel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Patient_panel.Controls.Add(this.flowLayoutPanel1);
            this.Patient_panel.Controls.Add(this.Current_patietn_view);
            this.Patient_panel.Controls.Add(this.Room_name);
            this.Patient_panel.Controls.Add(this.Break_txt);
            this.Patient_panel.Controls.Add(this.Current_patient_dob);
            this.Patient_panel.Controls.Add(this.patient_condition_txt);
            this.Patient_panel.Controls.Add(this.dob_txt);
            this.Patient_panel.Controls.Add(this.Current_patient_id);
            this.Patient_panel.Controls.Add(this.Patient_id_txt);
            this.Patient_panel.Controls.Add(this.Patient_name);
            this.Patient_panel.Controls.Add(this.Current_patient_room);
            this.Patient_panel.Controls.Add(this.Current_patient_pulse_colour);
            this.Patient_panel.Controls.Add(this.Current_patient_breathing_colour);
            this.Patient_panel.Controls.Add(this.Current_patient_blood_colour);
            this.Patient_panel.Controls.Add(this.Current_patient_temp_colour);
            this.Patient_panel.Location = new System.Drawing.Point(293, 142);
            this.Patient_panel.Name = "Patient_panel";
            this.Patient_panel.Size = new System.Drawing.Size(534, 275);
            this.Patient_panel.TabIndex = 5;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowLayoutPanel1.Controls.Add(this.Current_patient_notes);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(258, 29);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(236, 177);
            this.flowLayoutPanel1.TabIndex = 4;
            // 
            // Current_patient_notes
            // 
            this.Current_patient_notes.Location = new System.Drawing.Point(3, 0);
            this.Current_patient_notes.Name = "Current_patient_notes";
            this.Current_patient_notes.Size = new System.Drawing.Size(236, 175);
            this.Current_patient_notes.TabIndex = 0;
            this.Current_patient_notes.Text = "Notes";
            // 
            // Current_patietn_view
            // 
            this.Current_patietn_view.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Current_patietn_view.FlatAppearance.BorderSize = 3;
            this.Current_patietn_view.Location = new System.Drawing.Point(354, 212);
            this.Current_patietn_view.Name = "Current_patietn_view";
            this.Current_patietn_view.Size = new System.Drawing.Size(140, 48);
            this.Current_patietn_view.TabIndex = 2;
            this.Current_patietn_view.Text = "View Details";
            this.Current_patietn_view.UseVisualStyleBackColor = false;
            // 
            // Room_name
            // 
            this.Room_name.AutoSize = true;
            this.Room_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.Room_name.Location = new System.Drawing.Point(0, 0);
            this.Room_name.Name = "Room_name";
            this.Room_name.Size = new System.Drawing.Size(58, 20);
            this.Room_name.TabIndex = 1;
            this.Room_name.Text = "Room:";
            // 
            // Break_txt
            // 
            this.Break_txt.AutoSize = true;
            this.Break_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.Break_txt.Location = new System.Drawing.Point(80, 0);
            this.Break_txt.Name = "Break_txt";
            this.Break_txt.Size = new System.Drawing.Size(17, 25);
            this.Break_txt.TabIndex = 1;
            this.Break_txt.Text = "l";
            // 
            // Current_patient_dob
            // 
            this.Current_patient_dob.AutoSize = true;
            this.Current_patient_dob.Location = new System.Drawing.Point(96, 67);
            this.Current_patient_dob.Name = "Current_patient_dob";
            this.Current_patient_dob.Size = new System.Drawing.Size(103, 13);
            this.Current_patient_dob.TabIndex = 1;
            this.Current_patient_dob.Text = "Current_patient_dob";
            // 
            // patient_condition_txt
            // 
            this.patient_condition_txt.AutoSize = true;
            this.patient_condition_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.patient_condition_txt.Location = new System.Drawing.Point(21, 92);
            this.patient_condition_txt.Name = "patient_condition_txt";
            this.patient_condition_txt.Size = new System.Drawing.Size(90, 13);
            this.patient_condition_txt.TabIndex = 1;
            this.patient_condition_txt.Text = "Patient Condition:";
            // 
            // dob_txt
            // 
            this.dob_txt.AutoSize = true;
            this.dob_txt.Location = new System.Drawing.Point(21, 67);
            this.dob_txt.Name = "dob_txt";
            this.dob_txt.Size = new System.Drawing.Size(69, 13);
            this.dob_txt.TabIndex = 1;
            this.dob_txt.Text = "Date of Birth:";
            // 
            // Current_patient_id
            // 
            this.Current_patient_id.AutoSize = true;
            this.Current_patient_id.Location = new System.Drawing.Point(66, 29);
            this.Current_patient_id.Name = "Current_patient_id";
            this.Current_patient_id.Size = new System.Drawing.Size(77, 13);
            this.Current_patient_id.TabIndex = 1;
            this.Current_patient_id.Text = "Current Patient";
            // 
            // Patient_id_txt
            // 
            this.Patient_id_txt.AutoSize = true;
            this.Patient_id_txt.Location = new System.Drawing.Point(3, 29);
            this.Patient_id_txt.Name = "Patient_id_txt";
            this.Patient_id_txt.Size = new System.Drawing.Size(57, 13);
            this.Patient_id_txt.TabIndex = 1;
            this.Patient_id_txt.Text = "Patient ID:";
            // 
            // Patient_name
            // 
            this.Patient_name.AutoSize = true;
            this.Patient_name.Location = new System.Drawing.Point(97, 6);
            this.Patient_name.Name = "Patient_name";
            this.Patient_name.Size = new System.Drawing.Size(35, 13);
            this.Patient_name.TabIndex = 1;
            this.Patient_name.Text = "label1";
            // 
            // Current_patient_room
            // 
            this.Current_patient_room.AutoSize = true;
            this.Current_patient_room.Location = new System.Drawing.Point(56, 5);
            this.Current_patient_room.Name = "Current_patient_room";
            this.Current_patient_room.Size = new System.Drawing.Size(35, 13);
            this.Current_patient_room.TabIndex = 1;
            this.Current_patient_room.Text = "label1";
            // 
            // Current_patient_pulse_colour
            // 
            this.Current_patient_pulse_colour.BackColor = System.Drawing.Color.LightGreen;
            this.Current_patient_pulse_colour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Current_patient_pulse_colour.Controls.Add(this.Current_patient_condition);
            this.Current_patient_pulse_colour.Location = new System.Drawing.Point(24, 118);
            this.Current_patient_pulse_colour.Name = "Current_patient_pulse_colour";
            this.Current_patient_pulse_colour.Size = new System.Drawing.Size(200, 28);
            this.Current_patient_pulse_colour.TabIndex = 0;
            this.Current_patient_pulse_colour.Paint += new System.Windows.Forms.PaintEventHandler(this.Current_patient_pulse_Paint);
            // 
            // Current_patient_condition
            // 
            this.Current_patient_condition.AutoSize = true;
            this.Current_patient_condition.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Current_patient_condition.Location = new System.Drawing.Point(37, 8);
            this.Current_patient_condition.Name = "Current_patient_condition";
            this.Current_patient_condition.Size = new System.Drawing.Size(122, 13);
            this.Current_patient_condition.TabIndex = 1;
            this.Current_patient_condition.Text = "Current_patient_codition";
            // 
            // Current_patient_breathing_colour
            // 
            this.Current_patient_breathing_colour.BackColor = System.Drawing.Color.LightGreen;
            this.Current_patient_breathing_colour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Current_patient_breathing_colour.Controls.Add(this.Current_patient_breathing);
            this.Current_patient_breathing_colour.Location = new System.Drawing.Point(24, 152);
            this.Current_patient_breathing_colour.Name = "Current_patient_breathing_colour";
            this.Current_patient_breathing_colour.Size = new System.Drawing.Size(200, 28);
            this.Current_patient_breathing_colour.TabIndex = 0;
            // 
            // Current_patient_breathing
            // 
            this.Current_patient_breathing.AutoSize = true;
            this.Current_patient_breathing.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Current_patient_breathing.Location = new System.Drawing.Point(37, 6);
            this.Current_patient_breathing.Name = "Current_patient_breathing";
            this.Current_patient_breathing.Size = new System.Drawing.Size(129, 13);
            this.Current_patient_breathing.TabIndex = 1;
            this.Current_patient_breathing.Text = "Current_patient_breathing";
            // 
            // Current_patient_blood_colour
            // 
            this.Current_patient_blood_colour.BackColor = System.Drawing.Color.LightGreen;
            this.Current_patient_blood_colour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Current_patient_blood_colour.Controls.Add(this.Current_patient_blood);
            this.Current_patient_blood_colour.Location = new System.Drawing.Point(24, 186);
            this.Current_patient_blood_colour.Name = "Current_patient_blood_colour";
            this.Current_patient_blood_colour.Size = new System.Drawing.Size(200, 28);
            this.Current_patient_blood_colour.TabIndex = 0;
            // 
            // Current_patient_blood
            // 
            this.Current_patient_blood.AutoSize = true;
            this.Current_patient_blood.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Current_patient_blood.Location = new System.Drawing.Point(37, 6);
            this.Current_patient_blood.Name = "Current_patient_blood";
            this.Current_patient_blood.Size = new System.Drawing.Size(111, 13);
            this.Current_patient_blood.TabIndex = 1;
            this.Current_patient_blood.Text = "Current_patient_blood";
            // 
            // Current_patient_temp_colour
            // 
            this.Current_patient_temp_colour.BackColor = System.Drawing.Color.LightGreen;
            this.Current_patient_temp_colour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Current_patient_temp_colour.Controls.Add(this.Current_patient_temp);
            this.Current_patient_temp_colour.Location = new System.Drawing.Point(24, 220);
            this.Current_patient_temp_colour.Name = "Current_patient_temp_colour";
            this.Current_patient_temp_colour.Size = new System.Drawing.Size(200, 28);
            this.Current_patient_temp_colour.TabIndex = 0;
            // 
            // Current_patient_temp
            // 
            this.Current_patient_temp.AutoSize = true;
            this.Current_patient_temp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Current_patient_temp.Location = new System.Drawing.Point(33, 7);
            this.Current_patient_temp.Name = "Current_patient_temp";
            this.Current_patient_temp.Size = new System.Drawing.Size(108, 13);
            this.Current_patient_temp.TabIndex = 1;
            this.Current_patient_temp.Text = "Current_patient_temp";
            // 
            // Welcome_message
            // 
            this.Welcome_message.AutoSize = true;
            this.Welcome_message.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.Welcome_message.Location = new System.Drawing.Point(293, 45);
            this.Welcome_message.Name = "Welcome_message";
            this.Welcome_message.Size = new System.Drawing.Size(157, 31);
            this.Welcome_message.TabIndex = 6;
            this.Welcome_message.Text = "Welcome... ";
            // 
            // Welcome_employee
            // 
            this.Welcome_employee.AutoSize = true;
            this.Welcome_employee.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F);
            this.Welcome_employee.Location = new System.Drawing.Point(295, 88);
            this.Welcome_employee.Name = "Welcome_employee";
            this.Welcome_employee.Size = new System.Drawing.Size(126, 36);
            this.Welcome_employee.TabIndex = 7;
            this.Welcome_employee.Text = "Noname";
            this.Welcome_employee.Click += new System.EventHandler(this.Welcome_employee_Click);
            // 
            // Exit_btn
            // 
            this.Exit_btn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Exit_btn.FlatAppearance.BorderSize = 3;
            this.Exit_btn.Location = new System.Drawing.Point(784, 441);
            this.Exit_btn.Name = "Exit_btn";
            this.Exit_btn.Size = new System.Drawing.Size(135, 80);
            this.Exit_btn.TabIndex = 2;
            this.Exit_btn.Text = "Exit";
            this.Exit_btn.UseVisualStyleBackColor = false;
            this.Exit_btn.Click += new System.EventHandler(this.Exit_button_Click);
            // 
            // Add_patient_btn
            // 
            this.Add_patient_btn.Location = new System.Drawing.Point(26, 441);
            this.Add_patient_btn.Name = "Add_patient_btn";
            this.Add_patient_btn.Size = new System.Drawing.Size(128, 64);
            this.Add_patient_btn.TabIndex = 8;
            this.Add_patient_btn.Text = "Add Patient";
            this.Add_patient_btn.UseVisualStyleBackColor = true;
            this.Add_patient_btn.Click += new System.EventHandler(this.Add_patient_btn_Click);
            // 
            // Managment_btn
            // 
            this.Managment_btn.Location = new System.Drawing.Point(190, 441);
            this.Managment_btn.Name = "Managment_btn";
            this.Managment_btn.Size = new System.Drawing.Size(139, 64);
            this.Managment_btn.TabIndex = 9;
            this.Managment_btn.Text = "Managment";
            this.Managment_btn.UseVisualStyleBackColor = true;
            this.Managment_btn.Click += new System.EventHandler(this.Managment_btn_Click);
            // 
            // Central_Station
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(931, 533);
            this.Controls.Add(this.Managment_btn);
            this.Controls.Add(this.Add_patient_btn);
            this.Controls.Add(this.Welcome_employee);
            this.Controls.Add(this.Exit_btn);
            this.Controls.Add(this.Welcome_message);
            this.Controls.Add(this.Patient_panel);
            this.Controls.Add(this.Patients_List);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Central_Station";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Patient_panel.ResumeLayout(false);
            this.Patient_panel.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.Current_patient_pulse_colour.ResumeLayout(false);
            this.Current_patient_pulse_colour.PerformLayout();
            this.Current_patient_breathing_colour.ResumeLayout(false);
            this.Current_patient_breathing_colour.PerformLayout();
            this.Current_patient_blood_colour.ResumeLayout(false);
            this.Current_patient_blood_colour.PerformLayout();
            this.Current_patient_temp_colour.ResumeLayout(false);
            this.Current_patient_temp_colour.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox Patients_List;
        private System.Windows.Forms.Panel Patient_panel;
        private System.Windows.Forms.Label Welcome_message;
        private System.Windows.Forms.Label Welcome_employee;
        private System.Windows.Forms.Panel Current_patient_pulse_colour;
        private System.Windows.Forms.Panel Current_patient_breathing_colour;
        private System.Windows.Forms.Panel Current_patient_blood_colour;
        private System.Windows.Forms.Panel Current_patient_temp_colour;
        private System.Windows.Forms.Label Room_name;
        private System.Windows.Forms.Label Current_patient_room;
        private System.Windows.Forms.Label Patient_name;
        private System.Windows.Forms.Label Break_txt;
        private System.Windows.Forms.Label Patient_id_txt;
        private System.Windows.Forms.Label Current_patient_id;
        private System.Windows.Forms.Label dob_txt;
        private System.Windows.Forms.Label Current_patient_dob;
        private System.Windows.Forms.Label Current_patient_condition;
        private System.Windows.Forms.Label patient_condition_txt;
        private System.Windows.Forms.Label Current_patient_breathing;
        private System.Windows.Forms.Label Current_patient_blood;
        private System.Windows.Forms.Label Current_patient_temp;
        private System.Windows.Forms.Button Current_patietn_view;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label Current_patient_notes;
        private System.Windows.Forms.Button Exit_btn;
        private System.Windows.Forms.Button Add_patient_btn;
        private System.Windows.Forms.Button Managment_btn;
    }
}