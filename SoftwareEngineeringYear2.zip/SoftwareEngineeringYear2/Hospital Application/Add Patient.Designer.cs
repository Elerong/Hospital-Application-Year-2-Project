﻿namespace Hospital_Application
{
    partial class Add_Patient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.Add_patient_notes_txt = new System.Windows.Forms.RichTextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.New_patient_name_lb = new System.Windows.Forms.Label();
            this.New_patient_surname_lb = new System.Windows.Forms.Label();
            this.Add_patient_dob_lb = new System.Windows.Forms.Label();
            this.Add_patient_gender_lb = new System.Windows.Forms.Label();
            this.Add_patient_postcode_lb = new System.Windows.Forms.Label();
            this.Add_patient_house_lb = new System.Windows.Forms.Label();
            this.Add_patient_emergency_lb = new System.Windows.Forms.ComboBox();
            this.Add_emergency_lb = new System.Windows.Forms.Label();
            this.Add_patient_btn = new System.Windows.Forms.Button();
            this.cancel_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(243, 28);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(331, 32);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(243, 82);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(331, 33);
            this.textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(243, 138);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(331, 33);
            this.textBox3.TabIndex = 2;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(243, 239);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(331, 31);
            this.textBox4.TabIndex = 5;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(243, 291);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(331, 32);
            this.textBox5.TabIndex = 6;
            // 
            // Add_patient_notes_txt
            // 
            this.Add_patient_notes_txt.Location = new System.Drawing.Point(33, 355);
            this.Add_patient_notes_txt.Name = "Add_patient_notes_txt";
            this.Add_patient_notes_txt.Size = new System.Drawing.Size(541, 182);
            this.Add_patient_notes_txt.TabIndex = 7;
            this.Add_patient_notes_txt.Text = "";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBox1.Location = new System.Drawing.Point(243, 189);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(331, 28);
            this.comboBox1.TabIndex = 8;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // New_patient_name_lb
            // 
            this.New_patient_name_lb.AutoSize = true;
            this.New_patient_name_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.New_patient_name_lb.Location = new System.Drawing.Point(113, 35);
            this.New_patient_name_lb.Name = "New_patient_name_lb";
            this.New_patient_name_lb.Size = new System.Drawing.Size(94, 20);
            this.New_patient_name_lb.TabIndex = 9;
            this.New_patient_name_lb.Text = "First name:";
            // 
            // New_patient_surname_lb
            // 
            this.New_patient_surname_lb.AutoSize = true;
            this.New_patient_surname_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.New_patient_surname_lb.Location = new System.Drawing.Point(126, 82);
            this.New_patient_surname_lb.Name = "New_patient_surname_lb";
            this.New_patient_surname_lb.Size = new System.Drawing.Size(81, 20);
            this.New_patient_surname_lb.TabIndex = 10;
            this.New_patient_surname_lb.Text = "Surname:";
            // 
            // Add_patient_dob_lb
            // 
            this.Add_patient_dob_lb.AutoSize = true;
            this.Add_patient_dob_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.Add_patient_dob_lb.Location = new System.Drawing.Point(12, 144);
            this.Add_patient_dob_lb.Name = "Add_patient_dob_lb";
            this.Add_patient_dob_lb.Size = new System.Drawing.Size(219, 20);
            this.Add_patient_dob_lb.TabIndex = 11;
            this.Add_patient_dob_lb.Text = "Date of Birth: DD/MM/YYYY";
            // 
            // Add_patient_gender_lb
            // 
            this.Add_patient_gender_lb.AutoSize = true;
            this.Add_patient_gender_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.Add_patient_gender_lb.Location = new System.Drawing.Point(138, 189);
            this.Add_patient_gender_lb.Name = "Add_patient_gender_lb";
            this.Add_patient_gender_lb.Size = new System.Drawing.Size(69, 20);
            this.Add_patient_gender_lb.TabIndex = 12;
            this.Add_patient_gender_lb.Text = "Gender:";
            // 
            // Add_patient_postcode_lb
            // 
            this.Add_patient_postcode_lb.AutoSize = true;
            this.Add_patient_postcode_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.Add_patient_postcode_lb.Location = new System.Drawing.Point(117, 247);
            this.Add_patient_postcode_lb.Name = "Add_patient_postcode_lb";
            this.Add_patient_postcode_lb.Size = new System.Drawing.Size(92, 20);
            this.Add_patient_postcode_lb.TabIndex = 13;
            this.Add_patient_postcode_lb.Text = "Post Code:";
            // 
            // Add_patient_house_lb
            // 
            this.Add_patient_house_lb.AutoSize = true;
            this.Add_patient_house_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.Add_patient_house_lb.Location = new System.Drawing.Point(82, 296);
            this.Add_patient_house_lb.Name = "Add_patient_house_lb";
            this.Add_patient_house_lb.Size = new System.Drawing.Size(127, 20);
            this.Add_patient_house_lb.TabIndex = 14;
            this.Add_patient_house_lb.Text = "House Number:";
            // 
            // Add_patient_emergency_lb
            // 
            this.Add_patient_emergency_lb.FormattingEnabled = true;
            this.Add_patient_emergency_lb.Items.AddRange(new object[] {
            "Red",
            "Orange",
            "Green"});
            this.Add_patient_emergency_lb.Location = new System.Drawing.Point(797, 300);
            this.Add_patient_emergency_lb.Name = "Add_patient_emergency_lb";
            this.Add_patient_emergency_lb.Size = new System.Drawing.Size(121, 21);
            this.Add_patient_emergency_lb.TabIndex = 15;
            // 
            // Add_emergency_lb
            // 
            this.Add_emergency_lb.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.Add_emergency_lb.AutoSize = true;
            this.Add_emergency_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.Add_emergency_lb.Location = new System.Drawing.Point(630, 300);
            this.Add_emergency_lb.Name = "Add_emergency_lb";
            this.Add_emergency_lb.Size = new System.Drawing.Size(137, 20);
            this.Add_emergency_lb.TabIndex = 16;
            this.Add_emergency_lb.Text = "Emergency level:";
            // 
            // Add_patient_btn
            // 
            this.Add_patient_btn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Add_patient_btn.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Add_patient_btn.Location = new System.Drawing.Point(788, 473);
            this.Add_patient_btn.Name = "Add_patient_btn";
            this.Add_patient_btn.Size = new System.Drawing.Size(146, 64);
            this.Add_patient_btn.TabIndex = 17;
            this.Add_patient_btn.Text = "Save";
            this.Add_patient_btn.UseVisualStyleBackColor = false;
            this.Add_patient_btn.Click += new System.EventHandler(this.Add_patient_btn_Click);
            // 
            // cancel_btn
            // 
            this.cancel_btn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.cancel_btn.Location = new System.Drawing.Point(605, 473);
            this.cancel_btn.Name = "cancel_btn";
            this.cancel_btn.Size = new System.Drawing.Size(151, 64);
            this.cancel_btn.TabIndex = 18;
            this.cancel_btn.Text = "Cancel";
            this.cancel_btn.UseVisualStyleBackColor = false;
            this.cancel_btn.Click += new System.EventHandler(this.cancel_btn_Click);
            // 
            // Add_Patient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 565);
            this.Controls.Add(this.cancel_btn);
            this.Controls.Add(this.Add_patient_btn);
            this.Controls.Add(this.Add_emergency_lb);
            this.Controls.Add(this.Add_patient_emergency_lb);
            this.Controls.Add(this.Add_patient_house_lb);
            this.Controls.Add(this.Add_patient_postcode_lb);
            this.Controls.Add(this.Add_patient_gender_lb);
            this.Controls.Add(this.Add_patient_dob_lb);
            this.Controls.Add(this.New_patient_surname_lb);
            this.Controls.Add(this.New_patient_name_lb);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.Add_patient_notes_txt);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Add_Patient";
            this.ShowIcon = false;
            this.Text = "Add_Patient";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.RichTextBox Add_patient_notes_txt;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label New_patient_name_lb;
        private System.Windows.Forms.Label New_patient_surname_lb;
        private System.Windows.Forms.Label Add_patient_dob_lb;
        private System.Windows.Forms.Label Add_patient_gender_lb;
        private System.Windows.Forms.Label Add_patient_postcode_lb;
        private System.Windows.Forms.Label Add_patient_house_lb;
        private System.Windows.Forms.ComboBox Add_patient_emergency_lb;
        private System.Windows.Forms.Label Add_emergency_lb;
        private System.Windows.Forms.Button Add_patient_btn;
        private System.Windows.Forms.Button cancel_btn;
    }
}