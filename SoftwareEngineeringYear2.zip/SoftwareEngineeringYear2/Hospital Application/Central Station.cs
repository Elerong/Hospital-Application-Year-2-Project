﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Application
{
    public partial class Central_Station : Form
    {
        public Central_Station()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Welcome_employee_Click(object sender, EventArgs e)
        {

        }

        private void Current_patient_pulse_Paint(object sender, PaintEventArgs e)
        {
            Current_patient_pulse_colour.BackColor = (Color.LightPink);
        }

        private void Exit_button_Click(object sender, EventArgs e)
        {
           
            Application.Exit();
        }

        private void Patients_List_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Managment_btn_Click(object sender, EventArgs e)
        {
            Managment Screen = new Managment();
            Screen.Show();
            this.Hide();
            
        }

        private void Add_patient_btn_Click(object sender, EventArgs e)
        {
            Add_Patient Screen = new Add_Patient();
            Screen.Show();
            this.Hide();
        }
    }
}
