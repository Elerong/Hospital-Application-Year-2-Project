﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Application
{
    public partial class Add_Patient : Form
    {
        public Add_Patient()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Add_patient_btn_Click(object sender, EventArgs e)
        {
            Central_Station Screen = new Central_Station();
            this.Hide();
            Screen.Show();
            MessageBox.Show("Patient: Example \nDOB: 01/01/2019 \nMale \nPatient ID: 000000");
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            Central_Station Screen = new Central_Station();
            this.Hide();
            Screen.Show();
        }
    }
}
